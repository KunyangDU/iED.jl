
"""
Lattice wrapper
"""
abstract type AbstractLattice end
abstract type SimpleLattice <: AbstractLattice end


